import React, { useState } from 'react';

export default function App() {
  const [connected, setConnected] = useState(false);

  return (
    <div className='p-8 text-center'>
      <h1 className='text-3xl font-bold mb-4'>Revolutionary Omegle</h1>
      {!connected ? (
        <button className='px-4 py-2 bg-blue-500 text-white rounded'
          onClick={() => setConnected(true)}>Start Chat</button>
      ) : (
        <p>Connected! (Chat UI goes here)</p>
      )}
    </div>
  );
}
