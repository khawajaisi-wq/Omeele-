import express from 'express';
import { WebSocketServer } from 'ws';

const app = express();
const PORT = process.env.PORT || 3001;

const server = app.listen(PORT, () => console.log('Backend running on', PORT));

const wss = new WebSocketServer({ server });
wss.on('connection', ws => {
  console.log('Client connected');
  ws.on('message', msg => {
    console.log('Received:', msg.toString());
    ws.send('Echo: ' + msg);
  });
});
