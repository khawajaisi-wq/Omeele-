# Revolutionary Omegle App

This is a fully deployable full-stack Omegle-style chat app.

## How to Run Locally
1. `cd backend && npm install && npm start`
2. `cd frontend && npm install && npm run dev`

## Deployment
- You can deploy backend on Render/Railway/Fly.io
- Deploy frontend on Vercel/Netlify and set `VITE_API_URL` to backend URL
